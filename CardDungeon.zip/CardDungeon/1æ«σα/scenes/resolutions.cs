using Godot;
using System;

public partial class resolutions : OptionButton
{
	public override void _Ready()
	{

	}
	public override void _Process(double delta)
	{

	}
}
